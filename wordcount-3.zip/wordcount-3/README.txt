These books are from the Standard Ebooks library, and text extracted with html2text.
Thanks to Standard Ebooks for creating beautifully-formatted ebooks in the public domain. https://standardebooks.org/
